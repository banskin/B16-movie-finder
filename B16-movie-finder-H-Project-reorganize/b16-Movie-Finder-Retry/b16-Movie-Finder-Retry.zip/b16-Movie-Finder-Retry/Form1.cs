﻿using System;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using TMDbLib.Client;
using TMDbLib.Objects.Search;
using TMDbLib.Objects.Movies;
using TMDbLib.Objects.General;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace movieFinder
{
	public partial class Form1 : Form
	{
		bool DBChoice;
        RootObject obj;
        string[] Moviearray = new string[40];
        int[] IDarray = new int[40];

        public Form1()
		{
			InitializeComponent();
			this.ActiveControl = textBox1;
		}
		public void button1_Click(object sender, EventArgs e)
		{
			DBChoice = true;
			listBox1.Items.Clear();
            textBox2.Clear();
			pictureBox1.Image = null;
            
			string UrlText = textBox1.Text.Replace(" ", "+");

			string URL = "http://www.omdbapi.com/?t=" + UrlText + "&apikey=3c1d34eb";

			WebRequest request = WebRequest.Create(URL);
			WebResponse response = request.GetResponse();
			string result = new StreamReader(response.GetResponseStream()).ReadToEnd();

            var json = result;
            obj = JsonConvert.DeserializeObject<RootObject>(json);

            

            string edited_text = result.Replace("\"", "");
			string edited_text2 = edited_text.Replace("{", "");
			string edited_text3 = edited_text.Replace("}", "");



			List<string> TagIds = edited_text2.Split(',').ToList<string>();
			foreach (string s in TagIds)
			{
				listBox1.Items.Add(s);

			}
			// Loop through and find each item that matches the search string.

			try
			{
				// Retrieve the item based on the previous index found. Starts with -1 which searches start.
				pictureBox1.Load(obj.Poster);
			}
			catch
			{
				listBox1.Items.Add("NO POSTER FOUND");
			}


		}

		public void button2_Click(object sender, EventArgs e)
		{
			DBChoice = false;
			listBox1.Items.Clear();
			pictureBox1.Image = null;
            ShowMorebtn.Visible = true;
            int i = 0;
            
			string UrlText = textBox1.Text.Replace(" ", "+");
            TMDbClient client = new TMDbClient("66be5bcbbf38f6554ac0af72889c52ae");

            SearchContainer<SearchMovie> movie = client.SearchMovieAsync(textBox1.Text).Result;
            foreach(SearchMovie result in movie.Results)
            {
                Moviearray[i] = result.Title;
                IDarray[i] = result.Id;
                listBox1.Items.Add(result.Title);
                i++;
            }

            // Loop through and find each item that matches the search string.

            
		}


		static Form2 f2 = new Form2();
		public void button3_Click(object sender, EventArgs e)
		{
			this.Hide();
			
			f2.Show();
		}

		private void button4_Click(object sender, EventArgs e) //Add to wishlist
		{
            int x = -1;

            x = listBox1.FindString("Title");

            string poster = listBox1.Items[x].ToString();

            poster = poster.Remove(0, 6);
            f2.listBox2.Items.Add(poster);
            
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}
		public void textBox1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			// Determine whether the key entered is the F1 key. If it is, display Help.
			if (e.KeyCode == Keys.Enter)
			{
				if (DBChoice == true)
					button1.PerformClick();
				else if (DBChoice == false)
					button2.PerformClick();
			}

		}

        private void ShowMorebtn_Click(object sender, EventArgs e)
        {
            TMDbClient client = new TMDbClient("66be5bcbbf38f6554ac0af72889c52ae");
            int x = listBox1.SelectedIndex;
            Movie movie = client.GetMovieAsync(IDarray[x]).Result;

            listBox1.Items.Clear();
            listBox1.Items.Add("Title: " + movie.Title);
            textBox2.Text = "Overview: " + movie.Overview;
            listBox1.Items.Add("Release Date: " + movie.ReleaseDate);
            listBox1.Items.Add("Runtime: " + movie.Runtime);
            listBox1.Items.Add("Movie Budget: " + movie.Budget);
            listBox1.Items.Add("Production Companies: " + movie.ProductionCompanies);
            listBox1.Items.Add("Original Language: " + movie.OriginalLanguage);
            listBox1.Items.Add("Popularity: " + movie.Popularity);

            try
            {
                // Retrieve the item based on the previous index found. Starts with -1 which searches start.

                pictureBox1.Load(movie.PosterPath);
            }
            catch
            {
                listBox1.Items.Add("NO POSTER FOUND");
                pictureBox1.Load("http://www.interlog.com/~tfs/images/posters/TFSMoviePosterUnavailable.jpg");
            }
        }
    }
    public class Rating
    {
        public string Source { get; set; }
        public string Value { get; set; }
    }

    public class RootObject
    {
        public string Title { get; set; }
        public string Year { get; set; }
        public string Rated { get; set; }
        public string Released { get; set; }
        public string Runtime { get; set; }
        public string Genre { get; set; }
        public string Director { get; set; }
        public string Writer { get; set; }
        public string Actors { get; set; }
        public string Plot { get; set; }
        public string Language { get; set; }
        public string Country { get; set; }
        public string Awards { get; set; }
        public string Poster { get; set; }
        public List<Rating> Ratings { get; set; }
        public string Metascore { get; set; }
        public string imdbRating { get; set; }
        public string imdbVotes { get; set; }
        public string imdbID { get; set; }
        public string Type { get; set; }
        public string totalSeasons { get; set; }
        public string Response { get; set; }
    }
}
