﻿namespace TMDbLib.Objects.Search
{
    public class SearchMovieWithRating : SearchMovie
    {
        public double Rating { get; set; }
    }
}