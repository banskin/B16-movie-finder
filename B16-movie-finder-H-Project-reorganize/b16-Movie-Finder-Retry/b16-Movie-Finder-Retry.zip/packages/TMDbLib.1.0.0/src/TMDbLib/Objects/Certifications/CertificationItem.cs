﻿namespace TMDbLib.Objects.Certifications
{
    public class CertificationItem
    {
        public string Certification { get; set; }
        public string Meaning { get; set; }
        public int Order { get; set; }
    }
}