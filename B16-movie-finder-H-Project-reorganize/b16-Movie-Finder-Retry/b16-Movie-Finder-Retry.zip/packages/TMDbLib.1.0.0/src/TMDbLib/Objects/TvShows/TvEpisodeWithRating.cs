﻿namespace TMDbLib.Objects.TvShows
{
    public class TvEpisodeWithRating : TvEpisode
    {
        public double Rating { get; set; }
    }
}