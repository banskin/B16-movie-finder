﻿namespace TMDbLib.Objects.Movies
{
    public enum MovieListType
    {
        NowPlaying,
        Popular,
        TopRated,
        Upcoming
    }
}