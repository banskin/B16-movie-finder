﻿namespace TMDbLib.Objects.People
{
    public enum PersonListType
    {
        Popular
    }
}