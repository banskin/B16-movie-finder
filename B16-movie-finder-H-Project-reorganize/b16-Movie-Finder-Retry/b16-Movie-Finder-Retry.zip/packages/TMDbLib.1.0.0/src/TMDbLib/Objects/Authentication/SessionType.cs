﻿namespace TMDbLib.Objects.Authentication
{
    public enum SessionType
    {
        Unassigned = 0,
        GuestSession = 1,
        UserSession = 2
    }
}
