﻿using System.Collections.Generic;
using TMDbLib.Objects.General;

namespace TMDbLib.Objects.Jobs
{
    public class JobContainer
    {
        public List<Job> Jobs { get; set; }
    }
}