namespace TMDbLib.Objects.People
{
    public enum PersonGender
    {
        Unknown,
        Female = 1,
        Male = 2
    }
}