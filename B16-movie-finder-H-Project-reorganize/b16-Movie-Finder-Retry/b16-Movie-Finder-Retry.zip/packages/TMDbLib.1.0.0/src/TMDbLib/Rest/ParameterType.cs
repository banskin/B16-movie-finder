namespace TMDbLib.Rest
{
    internal enum ParameterType
    {
        QueryString,
        UrlSegment
    }
}